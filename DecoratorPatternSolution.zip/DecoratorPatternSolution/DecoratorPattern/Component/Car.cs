﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 2:59 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace DecoratorPattern.Component
{
	/// <summary>
	/// Description of Car.
	/// </summary>
	public abstract class Car
	{
		public string Description{get;set;}
		public abstract string GetDescription();
		public abstract double GetCarPrice();
	}
}
