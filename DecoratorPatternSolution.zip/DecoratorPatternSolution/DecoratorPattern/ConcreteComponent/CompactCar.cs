﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 3:01 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using DecoratorPattern.Component;

namespace DecoratorPattern.ConcreteComponent
{
	/// <summary>
	/// Description of CompactCar.
	/// </summary>
	public class CompactCar : Car
	{
		public CompactCar()
		{
			Description="Compact Car";
		}
		
		public override string GetDescription()
		{
			return Description;
		}
		public override double GetCarPrice()
		{
			return 10000.00;
		}
	}
}
