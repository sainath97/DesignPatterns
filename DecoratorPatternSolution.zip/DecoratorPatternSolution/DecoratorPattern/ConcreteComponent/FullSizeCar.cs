﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 3:02 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using DecoratorPattern.Component;

namespace DecoratorPattern.ConcreteComponent
{
	/// <summary>
	/// Description of FullSizeCar.
	/// </summary>
	public class FullSizeCar : Car
	{
		public FullSizeCar()
		{
			Description="Full Size Car";
		}
		
		public override string GetDescription()
		{
			return Description;
		}
		
		public override double GetCarPrice()
		{
			return 30000.00;
		}
	}
}
