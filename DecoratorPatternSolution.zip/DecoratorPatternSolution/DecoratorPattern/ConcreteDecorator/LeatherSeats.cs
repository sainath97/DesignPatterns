﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 3:21 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using DecoratorPattern.Component;
using DecoratorPattern.Decorator;

namespace DecoratorPattern.ConcreteDecorator
{
	/// <summary>
	/// Description of LeatherSeats.
	/// </summary>
	public class LeatherSeats : CarDecorator
	{
		public LeatherSeats(Car car) : base(car)
		{
			Description="Leather Seats";
		}
		
		public override string GetDescription()
		{
			return _car.GetDescription() + ", " + Description;
		}
		
		public override double GetCarPrice()
		{
			return _car.GetCarPrice() + 3000.00;
		}
	}
}
