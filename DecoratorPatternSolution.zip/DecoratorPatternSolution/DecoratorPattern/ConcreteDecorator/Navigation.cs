﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 3:14 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using DecoratorPattern.Decorator;
using DecoratorPattern.Component;

namespace DecoratorPattern.ConcreteDecorator
{
	/// <summary>
	/// Description of Navigation.
	/// </summary>
	public class Navigation : CarDecorator
	{
		public Navigation(Car car) : base(car)
		{
			Description="Navigation";
		}
		
		public override string GetDescription()
		{
			return _car.GetDescription() + ", " + Description;
		}
		
		public override double GetCarPrice()
		{
			return _car.GetCarPrice() + 5000.00;
		}
	}
}
