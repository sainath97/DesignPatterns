﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 3:19 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using DecoratorPattern.Decorator;
using DecoratorPattern.Component;

namespace DecoratorPattern.ConcreteDecorator
{
	/// <summary>
	/// Description of Sunroof.
	/// </summary>
	public class Sunroof : CarDecorator
	{
		public Sunroof(Car car) : base(car)
		{
			Description="Sunroof";
		}
		
		public override string GetDescription()
		{
			return _car.GetDescription() + ", " + Description;
		}
		
		public override double GetCarPrice()
		{
			return _car.GetCarPrice() + 2000.00;
		}
	}
}
