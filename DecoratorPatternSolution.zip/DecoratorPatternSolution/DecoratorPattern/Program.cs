﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 2:58 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using DecoratorPattern.Component;
using DecoratorPattern.ConcreteComponent;
using DecoratorPattern.ConcreteDecorator;

namespace DecoratorPattern
{
	class Program
	{
		public static void Main(string[] args)
		{
			Car car=new CompactCar();
			Console.WriteLine(car.GetDescription());
			Console.WriteLine(car.GetCarPrice());
			car=new LeatherSeats(car);
			Console.WriteLine(car.GetDescription());
			Console.WriteLine(car.GetCarPrice());
			car=new Navigation(car);
			Console.WriteLine(car.GetDescription());
			Console.WriteLine(car.GetCarPrice());
			car=new Sunroof(car);
			Console.WriteLine(car.GetDescription());
			Console.WriteLine(car.GetCarPrice());
			Console.ReadKey(true);
		}
	}
}