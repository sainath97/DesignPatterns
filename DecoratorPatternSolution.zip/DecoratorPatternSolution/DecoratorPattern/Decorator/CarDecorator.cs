﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 3:09 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using DecoratorPattern.Component;

namespace DecoratorPattern.Decorator
{
	/// <summary>
	/// Description of CarDecorator.
	/// </summary>
	public class CarDecorator : Car
	{
		protected Car _car;
		
		public CarDecorator(Car car)
		{
			_car=car;
		}
		
		public override string GetDescription()
		{
			return _car.GetDescription();
		}
		
		public override double GetCarPrice()
		{
			return _car.GetCarPrice();
		}
	}
}
