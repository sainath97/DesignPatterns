﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 12:26 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace SingletonPattern.EagerInitialization
{
	/// <summary>
	/// Description of Policy.
	/// </summary>
	public class Policy
	{
		private static readonly Policy _instance=new Policy();
		
		private Policy()
		{
		}
		
		public static Policy GetInstance()
		{
			return _instance;
		}
	}
}
