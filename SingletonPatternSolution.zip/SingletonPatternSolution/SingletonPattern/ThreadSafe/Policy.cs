﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 12:31 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace SingletonPattern.ThreadSafe
{
	/// <summary>
	/// Description of Policy.
	/// </summary>
	public class Policy
	{
		private static Policy _instance=null;
		private static readonly object _lock=new object();
		
		private Policy()
		{
		}
		
		public static Policy GetInstance()
		{
			lock(_lock)
			{
				if(_instance==null){
					_instance=new Policy();
				}
				return _instance;
			}
		}
	}
}
