﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace SingletonPattern.LazyInitialization
{
	/// <summary>
	/// Description of Policy.
	/// </summary>
	public sealed class Policy
	{
		private static Policy _instance=null;
		
		private Policy()
		{
		}
		
		public static Policy GetInstance()
		{
			if(_instance==null)
			{
				_instance=new Policy();
			}
			return _instance;
		}
	}
}
