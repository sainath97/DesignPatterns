﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 12:20 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using NUnit.Framework;

namespace UnitTest
{
	[TestFixture]
	public class IsPolicyASingleton
	{
		[Test]
		public void IsPolicyASingleton_Test()
		{
			Assert.AreSame(SingletonPattern.LazyInitialization.Policy.GetInstance(),SingletonPattern.LazyInitialization.Policy.GetInstance());
			Assert.AreSame(SingletonPattern.EagerInitialization.Policy.GetInstance(),SingletonPattern.EagerInitialization.Policy.GetInstance());
			Assert.AreSame(SingletonPattern.ThreadSafe.Policy.GetInstance(),SingletonPattern.ThreadSafe.Policy.GetInstance());
		}
	}
}
