﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/10/2019
 * Time: 11:40 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FactoryMethod
{
	/// <summary>
	/// Description of CreditCardFactory.
	/// </summary>
	public class CreditCardFactory : CardFactory
    {
        public override CreditCard GetCreditCard(int  cardTypeId)
        {
            switch (cardTypeId)
            {
                case 1: 
                    return new MoneyBackCreditCard();
                case 2:
                    return new TitaniumCreditCard();
                case 3:
                    return new PlatinumCreditCard();
                default:
                    throw new ArgumentException();
            }
        }
    }
}
