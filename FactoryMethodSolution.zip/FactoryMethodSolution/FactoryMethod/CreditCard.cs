﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/10/2019
 * Time: 11:35 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FactoryMethod
{
	/// <summary>
	/// Description of CreditCard.
	/// </summary>
	public abstract class CreditCard
	{
		public abstract string CardType{get;}
	    public int CreditLimit{get;set;}
		public int AnnualCharge{get;set;}
	        
		public override string ToString()
	    {
	       return "CardType : "+CardType+"\nCredit Limit : "+CreditLimit+"\nAnnual Charge : Rs. "+AnnualCharge;
	    }
	}
}
