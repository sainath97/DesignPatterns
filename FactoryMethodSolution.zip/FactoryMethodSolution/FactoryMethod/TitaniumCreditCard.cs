﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/10/2019
 * Time: 11:38 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FactoryMethod
{
	/// <summary>
	/// Description of TitaniumCreditCard.
	/// </summary>
	public class TitaniumCreditCard : CreditCard
    {
		private readonly string _cardType;
		
		public override string CardType {
			get {
				return _cardType;
			}
		}
		
        public TitaniumCreditCard()
        {
            _cardType="Titanium";
            CreditLimit=100000;
            AnnualCharge=500;
        }
    }
}
