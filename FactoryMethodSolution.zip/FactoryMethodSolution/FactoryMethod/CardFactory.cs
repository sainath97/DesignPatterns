﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/10/2019
 * Time: 11:39 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FactoryMethod
{
	/// <summary>
	/// Description of CardFactory.
	/// </summary>
	public abstract class CardFactory
    {
        public abstract CreditCard GetCreditCard(int cardTypeId);
    }
}
