﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/10/2019
 * Time: 11:37 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FactoryMethod
{
	/// <summary>
	/// Description of MoneyBackCreditCard.
	/// </summary>
	public class MoneyBackCreditCard : CreditCard
    {
		private readonly string _cardType;
		
		public override string CardType {
			get {
				return _cardType;
			}
		}
		
        public MoneyBackCreditCard()
        {
            _cardType="MoneyBack";
            CreditLimit=50000;
            AnnualCharge=0;
        }
    }
}
