﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/10/2019
 * Time: 11:39 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FactoryMethod
{
	/// <summary>
	/// Description of PlatinumCreditCard.
	/// </summary>
	public class PlatinumCreditCard : CreditCard
    {
		private readonly string _cardType;
		
		public override string CardType {
			get {
				return _cardType;
			}
		}
		
        public PlatinumCreditCard()
        {
           	_cardType="Platinum";
            CreditLimit=500000;
            AnnualCharge=1000;
        }
    }
}
