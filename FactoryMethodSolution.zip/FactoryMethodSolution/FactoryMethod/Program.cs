﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/10/2019
 * Time: 11:25 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FactoryMethod
{
	public class Program
	{
		public static void Main(string[] args)
	    {
	        //Your code goes here
	        CardFactory factory=new CreditCardFactory();
	        Console.WriteLine("1. Money Back    2. Titanium     3. Platinum");
	        Console.Write("Chose the type of card to visit details: ");
	        int userChoice=Convert.ToInt32(Console.ReadLine());
			CreditCard creditCard=null;
	        switch (userChoice)
	        {
	            case 1:
	                creditCard=factory.GetCreditCard(1);
	                Console.WriteLine(creditCard.ToString());
	                break;
	            case 2:
	                creditCard=factory.GetCreditCard(2);
	                Console.WriteLine(creditCard.ToString());
	                break;
	            case 3:
	                creditCard=factory.GetCreditCard(3);
	                Console.WriteLine(creditCard.ToString());
	                break;
	            default:
	                Console.WriteLine("Invalid choice..");
	                break;
	        }
	        Console.ReadLine();
	    }
	}
}