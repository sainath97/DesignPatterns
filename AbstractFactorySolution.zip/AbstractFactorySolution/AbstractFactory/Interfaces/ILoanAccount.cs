﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 10:46 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace AbstractFactory.Interfaces
{
	/// <summary>
	/// Abstarct ProductA(LoanAccount).
	/// </summary>
	public interface ILoanAccount
	{
		
	}
}
