﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 10:44 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace AbstractFactory.Interfaces
{
	/// <summary>
	/// Abstract Factory(IBankFactory).
	/// </summary>
	public interface IBankFactory
	{
		ISavingsAccount GetSavingsAccount();
		ILoanAccount GetLoanAccount();
	}
}
