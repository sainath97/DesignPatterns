﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 10:50 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using AbstractFactory.Interfaces;

namespace AbstractFactory.CitiBank
{
	/// <summary>
	/// Concrete ProductA-1(CitiLoanAccount).
	/// </summary>
	public class CitiLoanAccount : ILoanAccount
	{
		public CitiLoanAccount()
		{
			Console.WriteLine("Returned Citi Loan Account");
		}
	}
}
