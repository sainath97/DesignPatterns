﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 10:53 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using AbstractFactory.Interfaces;

namespace AbstractFactory.CitiBank
{
	/// <summary>
	/// Concrete Factoy-1(CityBankFactory).
	/// </summary>
	public class CityBankFactory : IBankFactory
	{
		public ISavingsAccount GetSavingsAccount()
		{
			return new CitiSavingsAccount();
		}
		
		public ILoanAccount GetLoanAccount()
		{
			return new CitiLoanAccount();
		}
	}
}
