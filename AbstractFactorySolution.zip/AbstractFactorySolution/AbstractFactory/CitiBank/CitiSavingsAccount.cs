﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 10:52 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using AbstractFactory.Interfaces;

namespace AbstractFactory.CitiBank
{
	/// <summary>
	/// Concrete ProductB-1(CitiSavingsAccount).
	/// </summary>
	public class CitiSavingsAccount : ISavingsAccount
	{
		public CitiSavingsAccount()
		{
			Console.WriteLine("Returned Citi Savings Account");
		}
	}
}
