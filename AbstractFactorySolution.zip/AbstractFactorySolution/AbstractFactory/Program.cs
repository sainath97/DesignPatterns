﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 10:43 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using AbstractFactory.Interfaces;
using AbstractFactory.Providers;

namespace AbstractFactory
{
	class Program
	{
		public static void Main(string[] args)
		{
			var accountNumbers=new List<string>{
				"CITI-45631",
				"NATIONAL-587964",
				"SAS-45785"
			};
			foreach(var accountNumber in accountNumbers)
			{
				IBankFactory bankFactory=BankFactoryProvider.GetBankFactory(accountNumber);
				if(bankFactory==null)
				{
					Console.WriteLine("Sorry, The Account Number '{0}' is Invalid",accountNumber);
				}
				else
				{
					ILoanAccount loanAccount=bankFactory.GetLoanAccount();
					ISavingsAccount savingsAccount=bankFactory.GetSavingsAccount();
				}
			}
			
			Console.ReadKey(true);
		}
	}
}