﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 11:10 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using AbstractFactory.Interfaces;
using AbstractFactory.CitiBank;
using AbstractFactory.NationalBank;

namespace AbstractFactory.Providers
{
	/// <summary>
	/// Client(BankFactoryProvider).
	/// </summary>
	public static class BankFactoryProvider
	{
		public static IBankFactory GetBankFactory(string accountNumber)
		{
			if(accountNumber.Contains("CITI"))
			{
				return new CityBankFactory();
			}
			else if(accountNumber.Contains("NATIONAL"))
			{
				return new NationalBankFactory();
			}
			else
			{
				return null;
			}
		}
	}
}
