﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 11:02 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using AbstractFactory.Interfaces;

namespace AbstractFactory.NationalBank
{
	/// <summary>
	/// Abstract ProductB-2(NationalSavingsAccount).
	/// </summary>
	public class NationalSavingsAccount : ISavingsAccount
	{
		public NationalSavingsAccount()
		{
			Console.WriteLine("Retuned National Savings Account");
		}
	}
}
