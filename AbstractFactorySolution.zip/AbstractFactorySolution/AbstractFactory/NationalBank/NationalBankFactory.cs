﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 11:06 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using AbstractFactory.Interfaces;

namespace AbstractFactory.NationalBank
{
	/// <summary>
	/// Abstract Factory-2(NationalBankFactory).
	/// </summary>
	public class NationalBankFactory : IBankFactory
	{
		public ISavingsAccount GetSavingsAccount()
		{
			return new NationalSavingsAccount();
		}
		
		public ILoanAccount GetLoanAccount()
		{
			return new NationalLoanAccount();
		}
	}
}
