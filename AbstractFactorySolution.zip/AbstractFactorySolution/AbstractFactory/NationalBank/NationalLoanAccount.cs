﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 11:02 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using AbstractFactory.Interfaces;

namespace AbstractFactory.NationalBank
{
	/// <summary>
	/// Abstract ProductA-2(NationalLoanAccount).
	/// </summary>
	public class NationalLoanAccount : ILoanAccount
	{
		public NationalLoanAccount()
		{
			Console.WriteLine("Retuned National Savings Account");
		}
	}
}
