﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 5:49 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using ObserverPattern.Subject;

namespace ObserverPattern.Observer
{
	/// <summary>
	/// Description of IFan.
	/// </summary>
	public interface IFan
	{
		void Update(ICelebrity celebrity);
	}
}
