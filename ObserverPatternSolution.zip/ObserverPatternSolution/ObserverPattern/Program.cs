﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 5:46 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using ObserverPattern.Subject;
using ObserverPattern.ConcreteSubject;
using ObserverPattern.Observer;
using ObserverPattern.ConcreteObserver;

namespace ObserverPattern
{
	class Program
	{
		public static void Main(string[] args)
		{
			ICelebrity celebrity1=new Celebrity("Charlie Choplin");
			ICelebrity celebrity2=new Celebrity("APJ Abdul Kalam");
			
			IFan fan1=new Fan("Sainath");
			IFan fan2=new Fan("Gayathri");
			IFan fan3=new Fan("Hitesh");
			
			celebrity1.AddFollower(fan1);
			celebrity1.AddFollower(fan3);
			celebrity2.AddFollower(fan1);
			celebrity2.AddFollower(fan2);
			
			celebrity1.Tweet="Tweet by celebrity1";
			celebrity2.Tweet="Tweet by celebrity2";
			
			Console.ReadKey(true);
		}
	}
}