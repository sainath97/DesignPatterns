﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 5:56 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using ObserverPattern.Subject;
using ObserverPattern.Observer;

namespace ObserverPattern.ConcreteSubject
{
	/// <summary>
	/// Description of Celebrity.
	/// </summary>
	public class Celebrity : ICelebrity
	{
		private string _tweet;
		private string _fullName;
		private readonly List<IFan> _fans=new List<IFan>();
		
		public string FullName
		{
			get
			{
				return _fullName;
			}
		}
				
		public string Tweet{
			get{return _tweet;}
			set{Notify(value);}
		}
		
		public Celebrity(string fullName)
		{
			_fullName=fullName;
		}
		
		public void AddFollower(IFan fan)
		{
			_fans.Add(fan);
		}
		
		public void RemoveFollower(IFan fan)
		{
			_fans.Remove(fan);
		}
		
		public void Notify(string tweet)
		{
			_tweet=tweet;
			foreach(var fan in _fans)
			{
				fan.Update(this);
			}
		}
	}
}
