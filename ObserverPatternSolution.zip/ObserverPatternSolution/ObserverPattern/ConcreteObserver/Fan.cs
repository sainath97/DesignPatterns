﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 5:52 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using ObserverPattern.Observer;
using ObserverPattern.Subject;

namespace ObserverPattern.ConcreteObserver
{
	/// <summary>
	/// Description of Fan.
	/// </summary>
	public class Fan : IFan
	{
		public string FanName{get;set;}
		
		public Fan(string fanName)
		{
			FanName=fanName;
		}
		
		public void Update(ICelebrity celebrity)
		{
			Console.WriteLine("Fan {0} notified. Tweet of {1} : {2}",FanName,celebrity.FullName,celebrity.Tweet);
		}
	}
}
