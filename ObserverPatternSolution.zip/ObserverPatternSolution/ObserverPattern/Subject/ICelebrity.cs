﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 5:47 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using ObserverPattern.Observer;

namespace ObserverPattern.Subject
{
	/// <summary>
	/// Description of ICelebrity.
	/// </summary>
	public interface ICelebrity
	{
		string FullName{get;}
		string Tweet{get;set;}
		
		void Notify(string tweet);
		void AddFollower(IFan fan);
		void RemoveFollower(IFan fan);
		
	}
}
