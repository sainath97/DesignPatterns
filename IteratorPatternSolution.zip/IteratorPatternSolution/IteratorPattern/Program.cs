﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 4:38 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using IteratorPattern.Aggregate;
using IteratorPattern.Iterator;

namespace IteratorPattern
{
	class Program
	{
		public static void Main(string[] args)
		{
			INewsPaper nyp=new NYNewsPaper();
			INewsPaper lap=new LANewsPaper();
			IIterator nypIterator=nyp.CreateIterator();
			IIterator lapIterator=lap.CreateIterator();
			
			Console.WriteLine("========NYPaper reporters========");
			PrintReporters(nypIterator);
			Console.WriteLine("========LAPaper reporters========");
			PrintReporters(lapIterator);
			
			Console.ReadKey(true);
		}
		
		private static void PrintReporters(IIterator iterator)
		{
			iterator.First();
			while(!iterator.IsDone())
			{
				Console.WriteLine(iterator.Next());
			}
		}
	}
}