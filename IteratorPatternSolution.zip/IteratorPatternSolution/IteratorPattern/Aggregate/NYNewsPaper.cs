﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 4:47 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using IteratorPattern.Iterator;

namespace IteratorPattern.Aggregate
{
	/// <summary>
	/// Description of NYNewsPaper.
	/// </summary>
	public class NYNewsPaper : INewsPaper
	{
		private readonly List<string> _reporters;
		
		public NYNewsPaper()
		{
			_reporters=new List<string>{
				"David - NY",
				"Williams - NY",
				"Sarah - NY"
			};
		}
		
		public IIterator CreateIterator()
		{
			return new NYNewsPaperIterator(_reporters);
		}
	}
}
