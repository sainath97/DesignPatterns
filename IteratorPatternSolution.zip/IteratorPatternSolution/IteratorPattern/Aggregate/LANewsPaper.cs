﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 4:42 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using IteratorPattern.Iterator;

namespace IteratorPattern.Aggregate
{
	/// <summary>
	/// Description of LANewsPaper.
	/// </summary>
	public class LANewsPaper : INewsPaper
	{
		private readonly string[] _reporters;
		
		public LANewsPaper()
		{
			_reporters=new string[]{
				"Smith - LA",
				"Jordan - LA",
				"Chris - LA",
				"Nick - LA"
			};
		}
		
		public IIterator CreateIterator()
		{
			return new LANewsPaperIterator(_reporters);
		}
	}
}
