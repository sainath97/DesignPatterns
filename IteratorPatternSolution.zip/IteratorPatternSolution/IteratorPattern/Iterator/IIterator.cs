﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 4:39 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace IteratorPattern.Iterator
{
	/// <summary>
	/// Description of IIterator.
	/// </summary>
	public interface IIterator
	{
		void First();
		string Next();
		bool IsDone();
		string CurrentItem();
	}
}
