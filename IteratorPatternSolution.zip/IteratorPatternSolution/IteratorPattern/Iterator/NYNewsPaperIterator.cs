﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 4:51 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace IteratorPattern.Iterator
{
	/// <summary>
	/// Description of NYNewsPaperIterator.
	/// </summary>
	public class NYNewsPaperIterator : IIterator
	{
		private readonly List<string> _reporters;
		private int _current;
		
		public NYNewsPaperIterator(List<string> reporters)
		{
			_reporters=reporters;
			_current=0;
		}
		
		public string CurrentItem()
		{
			return _reporters[_current];
		}
		
		public void First()
		{
			_current=0;
		}
		
		public string Next()
		{
			return _reporters[_current++];
		}
		
		public bool IsDone()
		{
			return _current>=_reporters.Count;
		}
	}
}
