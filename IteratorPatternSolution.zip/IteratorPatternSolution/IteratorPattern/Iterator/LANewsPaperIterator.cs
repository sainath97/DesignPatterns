﻿/*
 * Created by SharpDevelop.
 * User: MAKAM ABHINAY
 * Date: 8/11/2019
 * Time: 4:51 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace IteratorPattern.Iterator
{
	/// <summary>
	/// Description of LANewsPaperIterator.
	/// </summary>
	public class LANewsPaperIterator : IIterator
	{
		private readonly string[] _reporters;
		private int _current;
		
		public LANewsPaperIterator(string[] reporters)
		{
			_reporters=reporters;
			_current=0;
		}
		
		public string CurrentItem()
		{
			return _reporters[_current];
		}
		
		public void First()
		{
			_current=0;
		}
		
		public string Next()
		{
			return _reporters[_current++];
		}
		
		public bool IsDone()
		{
			return _current>=_reporters.Length;
		}
	}
}
